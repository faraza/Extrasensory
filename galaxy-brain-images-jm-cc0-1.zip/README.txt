"Galaxy Brain", by Jon Manning

These images are a Creative Commons licensed version of the popular "Galaxy Brain" image
sequence. I created these to have a version that I can include in published work, without
worrying about infringing on other's copyright.

For more information about these images, see the blog post at
https://secretlab.institute/2021/02/15/cc-0-licensed-galaxy-brain-images/.

If you liked these images, please consider:
- Following me on Twitter: https://twitter.com/desplesda
- Checking out my studio: https://secretlab.games
- Contributing to our Patreon: https://patreon.com/secretlab

These images are licensed under the Creative Commons Zero 1.0 License
(https://creativecommons.org/publicdomain/zero/1.0/).

This work contains material from the following, the use of which is hereby acknowledged;
in particular, please note that some of these images are licensed under a Creative Commons
Attribution ("CC-BY") license, which requires you to acknowledge their use if you share,
modify, or otherwise these images.

* "Brain", by mahesh (CC-BY): blendswap.com/blend/13180
* "Stellar nursery in the arms of NGC 1672" by ESA/Hubble (CC-BY)
  esahubble.org/images/heic0706a/
* "Generic Male Basemesh (rigged)" by lsmft (CC-0) blendswap.com/blend/8395
* "Silhouette Photography Of Person Under Starry Sky" by egil sjøholt (Pexels License)
  pexels.com/photo/silhouette-photography-of-person-under-starry-sky-1906658/
* "Starry Night Sky" by Felix Mittermeier (Pexels License)
  pexels.com/photo/starry-night-sky-1205301/
* "Photography of Stars and Galaxy" by Free Nature Stock (CC-0)
  pexels.com/photo/photography-of-stars-and-galaxy-1376766/
* "Realistic Human Basemesh - Male and Female - Free Sample Preview Free low-poly 3D
  model" by Ozne000 (CGTrader Royalty Free License)
  cgtrader.com/free-3d-models/character/anatomy/realistic-human-basemesh-male-and-female-free-sample-preview

Thanks for reading!

Jon Manning
15 February 2021